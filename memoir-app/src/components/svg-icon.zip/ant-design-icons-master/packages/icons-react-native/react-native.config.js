module.exports = {
  dependency: {
    assets: ['fonts']
  }
};
