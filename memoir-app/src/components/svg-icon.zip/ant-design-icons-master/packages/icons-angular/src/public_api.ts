export * from './component/icon.service';
export * from './component/icon.directive';
export * from './component/icon.error';
export * from './component/icon.provider';
export * from './types';
export * from './utils';
export * from './manifest';
