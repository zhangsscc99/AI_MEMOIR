module.exports = {
  snapshotSerializers: ['enzyme-to-json/serializer'],
  verbose: true,
};
