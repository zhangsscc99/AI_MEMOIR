## custom-icon
<code src="../examples/custom-icon.tsx">
