## two-tone
<code src="../examples/two-tone.tsx">
